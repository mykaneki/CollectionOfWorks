import 'virtual:windi-base.css'
import 'virtual:windi-components.css'
// 你自定义的 css
import './styles/main.css'
import axios from 'axios'
import VueAxios from 'vue-axios'
import 'virtual:windi-utilities.css'
import 'virtual:windi-devtools'
import { AxiosInstance, AxiosRequestConfig } from 'axios'
import App from './App.vue'

const app = createApp(App)
const adminStore = AdminStore()
// 服务端地址
axios.defaults.baseURL = "http://localhost:8080"
app.use(VueAxios,axios)
// 独立API
const { message, notification, dialog } = createDiscreteApi([
	'message',
	'dialog',
	'notification',
])

app.provide("axios", axios)
app.provide("message", message)
app.provide("notification", notification)
app.provide("dialog", dialog)
app.provide("server_url", axios.defaults.baseURL )

// 添加请求拦截器
axios.interceptors.request.use(function (config) {
	// 在发送请求之前做些什么
	console.log(config)
		//每次请求都在headers中添加token
		if (config && config.headers) {
			config.headers.token = adminStore.token
			return config
		}
	return config;
}, function (error) {
	// 对请求错误做些什么
	console.error()
	return Promise.reject(error);
});

axios.interceptors.response.use(
  (response) => {
    if (response.status === 200) {
      return Promise.resolve(response);
    } else {
      return Promise.reject(response);
    }
  },
  // 服务器状态码不是200的情况
  (error) => {
    console.log(error);
    if (error === "Error: Network Error") {
      alert("网络错误，请检查网络连接");
    } else if (error.response && error.response.status) {
      switch (error.response.status) {
        case 500:
          alert("请求不存在-500");
          break;
        case 404:
          alert("请求不存在-404");
          break;
        // 其他错误，直接抛出错误提示
        default:
          alert("其他错误，请检查网络");
          break;
      }
    }
    return Promise.reject(error.response);
  }
);

app.mount('#app')
