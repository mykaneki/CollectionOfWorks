import { useRouter, useRoute } from 'vue-router'

export{ useRouter, useRoute }
