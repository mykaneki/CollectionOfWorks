<template>
  <md-editor v-model="text" />
</template>

<script setup>
import { ref } from 'vue';
import { defineComponent } from 'vue';
import MdEditor from 'md-editor-v3';
import 'md-editor-v3/lib/style.css';
// 内置了default、github、vuepress、mk-cute、smart-blue、cyanosis6 种主题
const state = reactive({
  text: '',
  theme: 'github'
});



// const text = ref('Hello Editor!');
</script>
