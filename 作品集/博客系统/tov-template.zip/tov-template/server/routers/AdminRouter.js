const express = require("express")
const router = express.Router()
const { v4: uuidv4 } = require("uuid")
const { db, genid } = require("../db/DbUtils")

router.post("/login", async (req, res) => {
    let select_admin_sql = "select * from `admin` where `account` = ? AND `password` = ?"
    let { account, password } = req.body;
    let { err, rows } = await db.async.all(select_admin_sql, [account, password])
    // 不出错，并且返回的结果大于0条
    if (err == null && rows.length > 0) {
        // 生成token
        let login_token = uuidv4();
        // token写入数据库
        let update_token_sql = "UPDATE `admin` SET `token` = ? where `id` = ?"
        await db.async.run(update_token_sql,[login_token,rows[0].id])
        // 将返回的数据赋给admin_info
        let admin_info = rows[0]
        admin_info.token = login_token
        // 将password清除，不返回给前端
        admin_info.password = ""

        res.send({
            code: 200,
            msg: "登录成功",
            data:admin_info
        })
    } else {
        res.send({
            code: 500,
            msg: "登录失败"
        })
    }

})

module.exports = router